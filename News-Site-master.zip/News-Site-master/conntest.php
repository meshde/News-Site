<?php
include 'dbhelper.php';
connection_test();
?>
